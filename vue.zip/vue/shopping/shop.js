var vm = new Vue({
        el:'#app',
        data:{
            total: 0,
            totalAll: 0,
            goods: [],
            checkAllFlag: false,
            seen: false,
            delFlag: true
        },
        filters:{

        },
        mounted: function () {
            this.goodlist();
        },
        methods:{
            changeNum:function (item,flag) {
                            if (flag>0) {
                                item.number++;
                                }else{
                                	item.number--;
                                	if(item.number<1){
                                		item.number = 1;
                                	}       
                                  }
                            this.totalMoney();
            },
            check:function (item) {
            	if(typeof item.checked == 'undefined'){
            		this.$set(item,"checked",true);
            	}else{
            		item.checked = !item.checked;
            	}
            	this.totalMoney();
            },
            goodlist:function () {  
                var self = this;
                this.$http.get("shop.json").then(function (res) {
                    self.goods = res.data.result.goods;
                },function () {
                    console.log("failed");
                });
            },
            checkAll:function (flag) {
            	this.checkAllFlag = flag;
            	var self = this;
            		this.goods.forEach(function(value,index){
            			if(typeof value.checked == 'undefined'){
                    		self.$set(value,"checked",self.checkAllFlag);
                    	}else{
                    		value.checked = self.checkAllFlag;
                    	}
            		});
            	this.totalMoney();
            },
            totalMoney:function () {
            	this.totalAll = 0;
            	var self =this;
            	this.goods.forEach(function(value,index){
            		if(value.checked){
            			self.totalAll += value.price * value.number;
            		}
            	});
            }      
        }
    })